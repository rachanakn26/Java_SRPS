/**
 * 
 */
/**
 * 
 */
module SRPS {
	requires java.sql;
}