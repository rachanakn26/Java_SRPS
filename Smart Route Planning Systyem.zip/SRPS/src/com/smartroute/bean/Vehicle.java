package com.smartroute.bean;

public class Vehicle {
    private int id;
    private String name;
    private String type;
    private double mileage;

    public Vehicle() {}

    public Vehicle(String name, String type, double mileage) {
        this.name = name;
        this.type = type;
        this.mileage = mileage;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public double getMileage() { return mileage; }
    public void setMileage(double mileage) { this.mileage = mileage; }
}