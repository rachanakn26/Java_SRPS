package com.smartroute.bean;

public class Booking {
    private int id;
    private int userId;
    private int routeId;
    private int vehicleId;

    public Booking() {}

    public Booking(int userId, int routeId, int vehicleId) {
        this.userId = userId;
        this.routeId = routeId;
        this.vehicleId = vehicleId;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public int getRouteId() { return routeId; }
    public void setRouteId(int routeId) { this.routeId = routeId; }

    public int getVehicleId() { return vehicleId; }
    public void setVehicleId(int vehicleId) { this.vehicleId = vehicleId; }
}