package com.smartroute.bean;

public class Route {
    private int id;
    private int sourceId;
    private int destinationId;
    private double distance;

    public Route() {}

    public Route(int sourceId, int destinationId, double distance) {
        this.sourceId = sourceId;
        this.destinationId = destinationId;
        this.distance = distance;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getSourceId() { return sourceId; }
    public void setSourceId(int sourceId) { this.sourceId = sourceId; }

    public int getDestinationId() { return destinationId; }
    public void setDestinationId(int destinationId) { this.destinationId = destinationId; }

    public double getDistance() { return distance; }
    public void setDistance(double distance) { this.distance = distance; }
}