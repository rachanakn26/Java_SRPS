package com.smartroute.main;

import java.util.Scanner;

import com.smartroute.dao.*;
import com.smartroute.daoimpl.*;

public class MainApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        UserDAO userDAO = new UserDAOImpl();
        LocationDAO locationDAO = new LocationDAOImpl();
        VehicleDAO vehicleDAO = new VehicleDAOImpl();
        RouteDAO routeDAO = new RouteDAOImpl();
        BookingDAO bookingDAO = new BookingDAOImpl();

        while (true) {

            System.out.println("\n===== SMART ROUTE PLANNER =====");
            System.out.println("1. Add User");
            System.out.println("2. Add Location");
            System.out.println("3. Add Vehicle");
            System.out.println("4. Add Route");
            System.out.println("5. Book Route");
            System.out.println("6. Show Distance");
            System.out.println("7. Show Estimated Time (60 km/hr)");
            System.out.println("8. Exit");
            System.out.print("Enter Choice: ");

            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    sc.nextLine();
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Email: ");
                    String email = sc.nextLine();
                    userDAO.addUser(name, email);
                    break;

                case 2:
                    sc.nextLine();
                    System.out.print("Enter Location Name: ");
                    String locName = sc.nextLine();
                    locationDAO.addLocation(locName);
                    break;

                case 3:
                    sc.nextLine();
                    System.out.print("Enter Vehicle Name: ");
                    String vName = sc.nextLine();
                    System.out.print("Enter Vehicle Type: ");
                    String vType = sc.nextLine();
                    System.out.print("Enter Mileage (km per litre): ");
                    double mileage = sc.nextDouble();
                    vehicleDAO.addVehicle(vName, vType, mileage);
                    break;

                case 4:
                    System.out.print("Enter Source Location ID: ");
                    int src = sc.nextInt();
                    System.out.print("Enter Destination Location ID: ");
                    int dest = sc.nextInt();
                    System.out.print("Enter Distance (km): ");
                    double dist = sc.nextDouble();
                    routeDAO.addRoute(src, dest, dist);
                    break;

                case 5:
                    System.out.print("Enter User ID: ");
                    int u = sc.nextInt();
                    System.out.print("Enter Route ID: ");
                    int r = sc.nextInt();
                    System.out.print("Enter Vehicle ID: ");
                    int v = sc.nextInt();
                    bookingDAO.bookRoute(u, r, v);
                    break;

                case 6:
                    System.out.print("Enter Route ID: ");
                    int routeId = sc.nextInt();
                    double distance = routeDAO.getDistance(routeId);
                    System.out.println("Route Distance: " + distance + " km");
                    break;

                case 7:
                    System.out.print("Enter Route ID: ");
                    int routeId2 = sc.nextInt();
                    double dist2 = routeDAO.getDistance(routeId2);
                    double time = dist2 / 60.0;   // fixed speed 60 km/hr
                    System.out.println("Estimated Time (60 km/hr): " + time + " hours");
                    break;

                case 8:
                    System.out.println("Thank You!");
                    sc.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid Choice");
            }
        }
    }
}