package com.smartroute.dao;

public interface UserDAO {
    void addUser(String name, String email);
}