package com.smartroute.dao;

public interface RouteDAO {
    void addRoute(int sourceId, int destinationId, double distance);
    double getDistance(int routeId);
}