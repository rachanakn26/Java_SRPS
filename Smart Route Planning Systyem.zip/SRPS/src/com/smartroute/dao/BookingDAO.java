package com.smartroute.dao;

public interface BookingDAO {
    void bookRoute(int userId, int routeId, int vehicleId);
}