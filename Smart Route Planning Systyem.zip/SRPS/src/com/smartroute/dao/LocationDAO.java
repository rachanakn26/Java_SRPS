package com.smartroute.dao;

public interface LocationDAO {
    void addLocation(String name);
}
