package com.smartroute.dao;

public interface VehicleDAO {
    void addVehicle(String name, String type, double mileage);
}
