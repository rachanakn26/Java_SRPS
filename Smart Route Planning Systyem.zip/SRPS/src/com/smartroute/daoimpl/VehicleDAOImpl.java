package com.smartroute.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.smartroute.dao.VehicleDAO;
import com.smartroute.util.DBConnection;

public class VehicleDAOImpl implements VehicleDAO {

    @Override
    public void addVehicle(String name, String type, double mileage) {

        String sql = "INSERT INTO vehicle(name,type,mileage) VALUES (?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setString(2, type);
            ps.setDouble(3, mileage);
            ps.executeUpdate();

            System.out.println("Vehicle Added Successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}