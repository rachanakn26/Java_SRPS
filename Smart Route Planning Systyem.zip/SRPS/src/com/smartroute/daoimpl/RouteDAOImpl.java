package com.smartroute.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.smartroute.dao.RouteDAO;
import com.smartroute.util.DBConnection;

public class RouteDAOImpl implements RouteDAO {

    @Override
    public void addRoute(int sourceId, int destinationId, double distance) {

        String sql = "INSERT INTO route(source_id,destination_id,distance) VALUES (?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, sourceId);
            ps.setInt(2, destinationId);
            ps.setDouble(3, distance);
            ps.executeUpdate();

            System.out.println("Route Added Successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public double getDistance(int routeId) {

        double distance = 0;
        String sql = "SELECT distance FROM route WHERE id=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, routeId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                distance = rs.getDouble("distance");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return distance;
    }
}