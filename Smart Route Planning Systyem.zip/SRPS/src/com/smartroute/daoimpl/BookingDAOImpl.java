package com.smartroute.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.smartroute.dao.BookingDAO;
import com.smartroute.util.DBConnection;

public class BookingDAOImpl implements BookingDAO {

    @Override
    public void bookRoute(int userId, int routeId, int vehicleId) {

        String sql = "INSERT INTO booking(user_id,route_id,vehicle_id) VALUES (?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setInt(2, routeId);
            ps.setInt(3, vehicleId);
            ps.executeUpdate();

            System.out.println("Booking Successful");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}