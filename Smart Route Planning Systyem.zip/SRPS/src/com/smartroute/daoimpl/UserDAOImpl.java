package com.smartroute.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.smartroute.dao.UserDAO;
import com.smartroute.util.DBConnection;

public class UserDAOImpl implements UserDAO {

    @Override
    public void addUser(String name, String email) {

        String sql = "INSERT INTO user(name,email) VALUES (?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setString(2, email);
            ps.executeUpdate();

            System.out.println("User Added Successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}