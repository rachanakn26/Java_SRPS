package com.smartroute.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.smartroute.dao.LocationDAO;
import com.smartroute.util.DBConnection;

public class LocationDAOImpl implements LocationDAO {

    @Override
    public void addLocation(String name) {

        String sql = "INSERT INTO location(name) VALUES (?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.executeUpdate();

            System.out.println("Location Added Successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}